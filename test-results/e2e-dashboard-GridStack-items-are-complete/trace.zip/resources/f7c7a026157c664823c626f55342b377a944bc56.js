(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__db6f46c6._.css",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_@headlessui_react_dist_60633ec1._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_22386cb2._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_dist_1237515d._.js",
  "static/chunks/node_modules_0cfe1b9c._.js",
  "static/chunks/_08ea0de2._.js"
],
    source: "dynamic"
});
