(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_17db664f._.js",
  "static/chunks/node_modules_gridstack_dist_1c85825a._.js",
  "static/chunks/node_modules_lodash_034a0376._.js",
  "static/chunks/node_modules_recharts_es6_07a88143._.js",
  "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_b0999871._.js",
  "static/chunks/node_modules_485a4091._.js",
  "static/chunks/node_modules_gridstack_dist_gridstack_min_02a2078f.css"
],
    source: "dynamic"
});
